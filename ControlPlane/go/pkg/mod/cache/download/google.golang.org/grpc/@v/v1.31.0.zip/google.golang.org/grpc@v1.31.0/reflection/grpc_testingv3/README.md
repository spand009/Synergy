The pb.go is genenated with an older version of codegen, to test reflection behavior with `grpc.SupportPackageIsVersion3`. DO NOT REGENERATE!

pb.go is manually edited to replace `"golang.org/x/net/context"` with `"context"`.
