Tests in this directory check that user errors invoking gorelease
are correctly reported.
