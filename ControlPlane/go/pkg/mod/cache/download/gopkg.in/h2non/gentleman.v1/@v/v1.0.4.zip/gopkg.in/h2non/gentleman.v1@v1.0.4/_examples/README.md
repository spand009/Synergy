# Examples

gentleman's examples showing multiple built-in features and common practical use cases.

### Usage

```bash
go run _examples/<example>/<example>.go
```

### Example

```bash
go run _examples/url/url.go
```
