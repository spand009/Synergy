package gentleman

// Version defines the package semantic version
const Version = "1.0.4"
