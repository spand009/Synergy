package pkg

func fn() {}
