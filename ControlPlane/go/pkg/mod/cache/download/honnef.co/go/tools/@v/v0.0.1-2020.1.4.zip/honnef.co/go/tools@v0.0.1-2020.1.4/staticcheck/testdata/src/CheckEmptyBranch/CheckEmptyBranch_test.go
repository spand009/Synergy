package pkg

import "testing"

func TestFoo(t *testing.T) {
	if true { // want `empty branch`
		// TODO
	}
}

func ExampleFoo() {
	if true {
		// TODO
	}
}
