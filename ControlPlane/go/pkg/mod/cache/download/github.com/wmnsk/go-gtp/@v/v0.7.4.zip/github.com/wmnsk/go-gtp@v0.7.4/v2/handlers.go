// Copyright 2019-2020 go-gtp authors. All rights reserved.
// Use of this source code is governed by a MIT-style license that can be
// found in the LICENSE file.

package v2

import (
	"net"
	"sync"

	"github.com/wmnsk/go-gtp/v2/ies"
	"github.com/wmnsk/go-gtp/v2/messages"
)

// HandlerFunc is a handler for specific GTPv2-C message.
type HandlerFunc func(c *Conn, senderAddr net.Addr, msg messages.Message) error

type msgHandlerMap struct {
	syncMap sync.Map
}

func (m *msgHandlerMap) store(msgType uint8, handler HandlerFunc) {
	m.syncMap.Store(msgType, handler)
}

func (m *msgHandlerMap) load(msgType uint8) (HandlerFunc, bool) {
	handler, ok := m.syncMap.Load(msgType)
	if !ok {
		return nil, false
	}

	return handler.(HandlerFunc), true
}

func newMsgHandlerMap(m map[uint8]HandlerFunc) *msgHandlerMap {
	mhm := &msgHandlerMap{syncMap: sync.Map{}}
	for k, v := range m {
		mhm.store(k, v)
	}

	return mhm
}

var defaultHandlerMap = newMsgHandlerMap(
	map[uint8]HandlerFunc{
		messages.MsgTypeEchoRequest:                   handleEchoRequest,
		messages.MsgTypeEchoResponse:                  handleEchoResponse,
		messages.MsgTypeVersionNotSupportedIndication: handleVersionNotSupportedIndication,
	},
)

func handleEchoRequest(c *Conn, senderAddr net.Addr, msg messages.Message) error {
	// this should never happen, as the type should have been assured by
	// msgHandlerMap before this function is called.
	if _, ok := msg.(*messages.EchoRequest); !ok {
		return &UnexpectedTypeError{Msg: msg}
	}

	// respond with EchoResponse.
	return c.RespondTo(
		senderAddr, msg, messages.NewEchoResponse(0, ies.NewRecovery(c.RestartCounter)),
	)
}

func handleEchoResponse(c *Conn, senderAddr net.Addr, msg messages.Message) error {
	// this should never happen, as the type should have been assured by
	// msgHandlerMap before this function is called.
	if _, ok := msg.(*messages.EchoResponse); !ok {
		return &UnexpectedTypeError{Msg: msg}
	}

	// do nothing.
	return nil
}

func handleVersionNotSupportedIndication(c *Conn, senderAddr net.Addr, msg messages.Message) error {
	// this should never happen, as the type should have been assured by
	// msgHandlerMap before this function is called.
	if _, ok := msg.(*messages.VersionNotSupportedIndication); !ok {
		return &UnexpectedTypeError{Msg: msg}
	}

	// let's just return err anyway.
	return &InvalidVersionError{Version: msg.Version()}
}
