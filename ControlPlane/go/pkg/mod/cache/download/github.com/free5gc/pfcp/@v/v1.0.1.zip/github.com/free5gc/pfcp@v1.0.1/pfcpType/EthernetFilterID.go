package pfcpType

type EthernetFilterID struct {
	EthernetFilterIDdata []byte
}
