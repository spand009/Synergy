package ngapType

// Need to import "github.com/free5gc/aper" if it uses "aper"

// Open type declare
type ProtocolIESingleContainerAMFPagingTargetExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerBroadcastCancelledAreaListExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerBroadcastCompletedAreaListExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerCauseExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerCellIDListForRestartExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerCPTransportLayerInformationExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerDRBStatusDLExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerDRBStatusULExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerGlobalRANNodeIDExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerGNBIDExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerLastVisitedCellInformationExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerN3IWFIDExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerNgENBIDExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerNGRANCGIExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerOverloadResponseExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerPWSFailedCellIDListExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerQosCharacteristicsExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerResetTypeExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerSONInformationExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerTargetIDExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerUEIdentityIndexValueExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerUENGAPIDsExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerUEPagingIdentityExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerUPTransportLayerInformationExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerUserLocationInformationExtIEs struct {
}

// Open type declare
type ProtocolIESingleContainerWarningAreaListExtIEs struct {
}
