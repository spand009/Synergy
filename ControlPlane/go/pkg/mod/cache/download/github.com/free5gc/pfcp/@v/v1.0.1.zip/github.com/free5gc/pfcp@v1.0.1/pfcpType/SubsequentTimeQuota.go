package pfcpType

type SubsequentTimeQuota struct {
	SubsequentTimeQuotadata []byte
}
