package ngapType

// Need to import "github.com/free5gc/aper" if it uses "aper"

type NGSetupFailure struct {
	ProtocolIEs ProtocolIEContainerNGSetupFailureIEs
}
