package pfcpType

type UsageReportTrigger struct {
	UsageReportTriggerdata []byte
}
