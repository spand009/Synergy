package pfcpType

type SequenceNumber struct {
	SequenceNumberdata []byte
}
