package pfcpType

type Reserved struct {
	Reserveddata []byte
}
