package pfcpType

type FQCSID struct {
	FQCSIDdata []byte
}
