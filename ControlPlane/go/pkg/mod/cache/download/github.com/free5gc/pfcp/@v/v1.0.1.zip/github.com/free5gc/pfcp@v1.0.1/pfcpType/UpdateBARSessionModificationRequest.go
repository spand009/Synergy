package pfcpType

type UpdateBARSessionModificationRequest struct {
	UpdateBARSessionModificationRequestdata []byte
}
