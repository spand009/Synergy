package pfcpType

type DLFlowLevelMarking struct {
	DLFlowLevelMarkingdata []byte
}
