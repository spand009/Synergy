package pfcpType

type FramedRouting struct {
	FramedRoutingdata []byte
}
