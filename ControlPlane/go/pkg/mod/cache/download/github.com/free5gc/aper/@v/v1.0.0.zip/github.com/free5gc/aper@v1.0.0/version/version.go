package version

// VERSION : lastest version
var VERSION = "2020-03-31-01"

// GetVersion : Get the latest version
func GetVersion() (version string) {
	return VERSION
}
