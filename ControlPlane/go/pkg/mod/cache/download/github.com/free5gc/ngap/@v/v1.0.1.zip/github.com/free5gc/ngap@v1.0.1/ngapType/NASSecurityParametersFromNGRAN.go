package ngapType

import "github.com/free5gc/aper"

// Need to import "github.com/free5gc/aper" if it uses "aper"

type NASSecurityParametersFromNGRAN struct {
	Value aper.OctetString
}
