package pfcpType

type MACAddress struct {
	MACAddressdata []byte
}
