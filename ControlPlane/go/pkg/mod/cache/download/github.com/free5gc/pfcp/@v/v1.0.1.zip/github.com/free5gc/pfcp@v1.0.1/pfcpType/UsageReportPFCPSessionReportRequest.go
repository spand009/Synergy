package pfcpType

type UsageReportPFCPSessionReportRequest struct {
	UsageReportPFCPSessionReportRequestdata []byte
}
