package pfcpType

type SubsequentVolumeQuota struct {
	SubsequentVolumeQuotadata []byte
}
