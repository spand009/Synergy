package pfcpType

type Metric struct {
	Metricdata []byte
}
