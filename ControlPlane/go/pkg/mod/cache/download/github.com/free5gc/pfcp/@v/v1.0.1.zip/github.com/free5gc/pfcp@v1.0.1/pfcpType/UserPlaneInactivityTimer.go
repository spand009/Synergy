package pfcpType

type UserPlaneInactivityTimer struct {
	UserPlaneInactivityTimerdata []byte
}
