package pfcpType

type EthernetPDUSessionInformation struct {
	EthernetPDUSessionInformationdata []byte
}
