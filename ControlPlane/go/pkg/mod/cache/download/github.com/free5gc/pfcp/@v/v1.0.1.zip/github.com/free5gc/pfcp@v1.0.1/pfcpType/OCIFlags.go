package pfcpType

type OCIFlags struct {
	OCIFlagsdata []byte
}
