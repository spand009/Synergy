package pfcpType

type ApplicationInstanceID struct {
	ApplicationInstanceIDdata []byte
}
