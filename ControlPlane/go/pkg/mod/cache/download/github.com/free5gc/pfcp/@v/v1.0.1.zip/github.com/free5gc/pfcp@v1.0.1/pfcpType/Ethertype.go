package pfcpType

type Ethertype struct {
	Ethertypedata []byte
}
