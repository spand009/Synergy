package pfcpType

type FramedIPv6Route struct {
	FramedIPv6Routedata []byte
}
