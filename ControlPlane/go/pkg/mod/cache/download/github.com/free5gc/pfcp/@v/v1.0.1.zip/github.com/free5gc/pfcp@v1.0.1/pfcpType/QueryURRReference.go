package pfcpType

type QueryURRReference struct {
	QueryURRReferencedata []byte
}
