package ngapType

// Need to import "github.com/free5gc/aper" if it uses "aper"

type CompletedCellsInTAINRItem struct {
	NRCGI        NRCGI                                                      `aper:"valueExt"`
	IEExtensions *ProtocolExtensionContainerCompletedCellsInTAINRItemExtIEs `aper:"optional"`
}
