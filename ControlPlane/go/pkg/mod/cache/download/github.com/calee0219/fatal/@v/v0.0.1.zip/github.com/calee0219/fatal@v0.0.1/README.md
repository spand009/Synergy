# fatal

help print and exit go program
