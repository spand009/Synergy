package pfcpType

type FramedRoute struct {
	FramedRoutedata []byte
}
