package pfcpType

type TraceInformation struct {
	TraceInformationdata []byte
}
