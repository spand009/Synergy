package pfcpType

type AdditionalUsageReportsInformation struct {
	AdditionalUsageReportsInformationdata []byte
}
