package pfcpType

type AggregatedURRID struct {
	AggregatedURRIDdata []byte
}
