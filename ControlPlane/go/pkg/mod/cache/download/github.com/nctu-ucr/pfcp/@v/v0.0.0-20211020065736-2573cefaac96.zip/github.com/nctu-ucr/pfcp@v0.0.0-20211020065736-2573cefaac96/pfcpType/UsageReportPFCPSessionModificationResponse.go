package pfcpType

type UsageReportPFCPSessionModificationResponse struct {
	UsageReportPFCPSessionModificationResponsedata []byte
}
