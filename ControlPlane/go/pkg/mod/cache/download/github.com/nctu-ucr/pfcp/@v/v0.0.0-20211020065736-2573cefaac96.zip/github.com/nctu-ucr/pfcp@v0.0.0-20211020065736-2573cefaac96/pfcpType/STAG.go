package pfcpType

type STAG struct {
	STAGdata []byte
}
