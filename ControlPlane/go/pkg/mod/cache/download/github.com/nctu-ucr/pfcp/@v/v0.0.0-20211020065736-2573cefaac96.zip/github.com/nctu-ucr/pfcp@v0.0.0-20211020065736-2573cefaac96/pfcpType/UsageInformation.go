package pfcpType

type UsageInformation struct {
	UsageInformationdata []byte
}
