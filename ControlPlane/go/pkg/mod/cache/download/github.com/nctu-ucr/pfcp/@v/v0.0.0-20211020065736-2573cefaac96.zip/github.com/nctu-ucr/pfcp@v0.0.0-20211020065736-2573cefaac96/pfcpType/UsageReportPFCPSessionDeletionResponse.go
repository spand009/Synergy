package pfcpType

type UsageReportPFCPSessionDeletionResponse struct {
	UsageReportPFCPSessionDeletionResponsedata []byte
}
