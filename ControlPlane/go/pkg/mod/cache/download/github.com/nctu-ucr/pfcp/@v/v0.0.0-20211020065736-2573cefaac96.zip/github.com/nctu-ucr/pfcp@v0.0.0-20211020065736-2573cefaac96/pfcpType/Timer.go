package pfcpType

type Timer struct {
	Timerdata []byte
}
