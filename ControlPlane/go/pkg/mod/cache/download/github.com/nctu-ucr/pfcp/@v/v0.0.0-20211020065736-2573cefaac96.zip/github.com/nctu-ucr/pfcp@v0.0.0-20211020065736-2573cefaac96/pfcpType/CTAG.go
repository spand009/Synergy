package pfcpType

type CTAG struct {
	CTAGdata []byte
}
