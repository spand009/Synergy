package pfcpType

type Proxying struct {
	Proxyingdata []byte
}
