package pfcpType

type UserID struct {
	UserIDdata []byte
}
