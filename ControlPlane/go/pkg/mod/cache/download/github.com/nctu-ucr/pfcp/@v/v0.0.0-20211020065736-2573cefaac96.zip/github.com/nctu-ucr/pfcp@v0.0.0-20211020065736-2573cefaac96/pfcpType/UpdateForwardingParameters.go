package pfcpType

type UpdateForwardingParameters struct {
	UpdateForwardingParametersdata []byte
}
