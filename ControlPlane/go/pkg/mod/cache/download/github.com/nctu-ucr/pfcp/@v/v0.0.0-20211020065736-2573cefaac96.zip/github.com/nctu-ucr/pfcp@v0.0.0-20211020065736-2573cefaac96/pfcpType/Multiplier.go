package pfcpType

type Multiplier struct {
	Multiplierdata []byte
}
