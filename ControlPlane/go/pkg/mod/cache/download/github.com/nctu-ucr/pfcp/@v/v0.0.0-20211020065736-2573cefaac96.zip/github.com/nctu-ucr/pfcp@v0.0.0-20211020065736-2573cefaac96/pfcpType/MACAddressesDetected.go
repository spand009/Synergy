package pfcpType

type MACAddressesDetected struct {
	MACAddressesDetecteddata []byte
}
