package pfcpType

type DuplicatingParameters struct {
	DuplicatingParametersdata []byte
}
