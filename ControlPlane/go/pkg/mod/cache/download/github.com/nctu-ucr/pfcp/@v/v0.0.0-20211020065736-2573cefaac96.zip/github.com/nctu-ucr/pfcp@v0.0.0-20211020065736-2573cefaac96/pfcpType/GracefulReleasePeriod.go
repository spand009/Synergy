package pfcpType

type GracefulReleasePeriod struct {
	GracefulReleasePerioddata []byte
}
