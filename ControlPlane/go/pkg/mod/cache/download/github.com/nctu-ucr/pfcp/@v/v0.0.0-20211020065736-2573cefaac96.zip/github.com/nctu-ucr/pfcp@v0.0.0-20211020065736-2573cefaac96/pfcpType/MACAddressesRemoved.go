package pfcpType

type MACAddressesRemoved struct {
	MACAddressesRemoveddata []byte
}
