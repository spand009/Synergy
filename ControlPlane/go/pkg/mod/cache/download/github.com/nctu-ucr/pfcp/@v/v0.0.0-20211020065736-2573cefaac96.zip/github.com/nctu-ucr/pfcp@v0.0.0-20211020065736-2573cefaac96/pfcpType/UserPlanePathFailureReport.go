package pfcpType

type UserPlanePathFailureReport struct {
	UserPlanePathFailureReportdata []byte
}
