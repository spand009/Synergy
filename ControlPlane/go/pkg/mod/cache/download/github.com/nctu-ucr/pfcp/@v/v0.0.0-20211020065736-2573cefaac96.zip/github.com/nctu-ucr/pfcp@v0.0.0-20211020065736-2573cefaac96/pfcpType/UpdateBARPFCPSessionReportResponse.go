package pfcpType

type UpdateBARPFCPSessionReportResponse struct {
	UpdateBARPFCPSessionReportResponsedata []byte
}
