package pfcpType

type FlowInformation struct {
	FlowInformationdata []byte
}
