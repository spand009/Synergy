package pfcpType

type TimeQuotaMechanism struct {
	TimeQuotaMechanismdata []byte
}
