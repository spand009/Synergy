package pfcpType

type UpdateDuplicatingParameters struct {
	UpdateDuplicatingParametersdata []byte
}
