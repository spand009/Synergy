package pfcpType

type PFDContext struct {
	PFDContextdata []byte
}
