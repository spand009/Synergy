package pfcpType

type EthernetFilterProperties struct {
	EthernetFilterPropertiesdata []byte
}
