package goshared

const numTpl = `
	{{ template "const" . }}
	{{ template "ltgt" . }}
	{{ template "in" . }}
`
