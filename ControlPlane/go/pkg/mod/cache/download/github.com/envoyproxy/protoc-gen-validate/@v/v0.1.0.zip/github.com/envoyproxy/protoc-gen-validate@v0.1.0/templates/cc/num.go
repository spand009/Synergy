package cc

const numTpl = `
	{{ template "const" . }}
	{{ template "ltgt" . }}
	{{ template "in" . }}
`
