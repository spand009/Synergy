This directory contains a copy of the
[gogoproto](https://github.com/gogo/protobuf) annotations processed using the
regular protoc golang plugin. The annotations are needed to import the protobuf
descriptor declarations into the validation plugin.
