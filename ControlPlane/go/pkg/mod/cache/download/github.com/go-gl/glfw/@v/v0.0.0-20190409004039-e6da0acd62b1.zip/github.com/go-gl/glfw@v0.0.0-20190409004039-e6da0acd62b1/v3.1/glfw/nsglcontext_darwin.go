package glfw

/*
#cgo CFLAGS: -x objective-c
#ifdef _GLFW_NSGL
	#include "glfw/src/nsgl_context.m"
#endif
*/
import "C"
