#ifdef _GLFW_X11
	#include "glfw/src/x11_init.c"
#endif

