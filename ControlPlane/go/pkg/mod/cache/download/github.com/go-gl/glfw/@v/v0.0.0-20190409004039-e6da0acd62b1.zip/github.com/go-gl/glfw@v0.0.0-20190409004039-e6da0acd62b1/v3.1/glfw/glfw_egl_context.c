#ifdef _GLFW_EGL
	#include "glfw/src/egl_context.c"
#endif

