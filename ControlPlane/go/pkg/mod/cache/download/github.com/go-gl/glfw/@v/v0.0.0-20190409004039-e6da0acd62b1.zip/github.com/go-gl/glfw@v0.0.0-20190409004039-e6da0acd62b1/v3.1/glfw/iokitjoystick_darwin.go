package glfw

/*
#cgo CFLAGS: -x objective-c
#ifdef _GLFW_COCOA
	#include "glfw/src/iokit_joystick.m"
#endif
*/
import "C"
